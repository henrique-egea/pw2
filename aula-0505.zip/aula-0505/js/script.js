var x, soma = 0;
while(x<5){
    console.log("Repetição: ", soma);
    soma = soma + x;
    x++;
}
var y = 0;
var z = ["1", "2", "3", "4", "5", "6"]
while(y <= 5){
    console.log(z[y])
    y++
}
var palavra = "THIAGO"
var i = 0
while(i < 6){
    console.log(palavra[i])
    i++
}
