var n1 = document.querySelector("#n1")
var n2 = document.querySelector("#n2")
var resultado = document.querySelector("#resultado")
var _lucro_ = document.querySelector("#lucro")
var _desconto_ = document.querySelector("#desconto")

function somar(){
    if(n1.value >= 1000){
        resultado.innerHTML = calculo(n1.value, n2.value) - (calculo(n1.value - n2.value) * 0.07)
    }
    else if(n1.value <= 500){
        _lucro_.innerHTML = calculo(n1.value, n2.value) * 0.07
        resultado.innerHTML = calculo(n1.value, n2.value)
    }
    else if(n1 <= 200){
        resultado.innerHTML = calculo(n1.value, n2.value)
        alert("Boa compra :3")
    }

}

function lucro(){
    _lucro_.innerHTML = calculo(n1.value, n2.value) * 0.15
}

function desconto(){
    _desconto_.innerHTML = calculo(n1.value, n2.value) * 0.03
}

function calculo(n1, n2){
    return (Number(n1) - (n1 * 0.1)) + Number(n2)
}

