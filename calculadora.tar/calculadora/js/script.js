function soma(){
    var a = parseInt(prompt("insira o primeiro valor"))
    var b = parseInt(prompt("Insira o segundo valor"))
    var r = a + b
    alert("resultado: " + r)
}
function subtracao(){
    var a = parseInt(prompt("insira o primeiro valor"))
    var b = parseInt(prompt("Insira o segundo valor"))
    var r = a - b
    alert("resultado: " + r)
}
function multiplicacao(){
    var a = parseInt(prompt("insira o primeiro valor"))
    var b = parseInt(prompt("Insira o segundo valor"))
    var r = a * b
    alert("resultado: " + r)
}
function divisao(){
    var a = parseInt(prompt("insira o primeiro valor"))
    var b = parseInt(prompt("Insira o segundo valor"))
    var r = a / b
    alert("resultado: " + r)
}
function triangulo(){
    var a = parseInt(prompt("insira o valor da base do triângulo"))
    var b = parseInt(prompt("Insira o valo da altura do triângulo"))
    var r = (a * b) / 2
    alert("resultado: " + r + "m²")
}
function quadrado(){
    var a = parseInt(prompt("insira o valor de uma vértice do quadrado"))
    var r = a * a
    alert("resultado: " + r)
}
function idade(){
    var a = parseInt(prompt("insira sua idade"))
    if(a >= 18){
        alert("Maior de idade")
    }
    else{
        alert("Menor de idade")
    }
}
function parouimpar(){
    var a = parseInt(prompt("insira um número"))
    if (a % 2 == 0) {
        alert("Par")
    } else {
        alert("Impar")
    }
}
    